﻿namespace Cars.Utilities
{
    using System;
    using System.Linq;

    public class CustomDealer
    {
        public string Name { get; set; }

        public string City { get; set; }
    }
}