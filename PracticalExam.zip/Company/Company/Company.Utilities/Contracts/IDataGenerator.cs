﻿namespace Company.Utilities.Contracts
{
    using System;
    using System.Linq;

    public interface IDataGenerator
    {
        void Generate();
    }
}