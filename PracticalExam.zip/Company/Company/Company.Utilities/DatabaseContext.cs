﻿namespace Company.Utilities
{
    using Company.Data;

    public class DatabaseContext : CompanyEntities
    {
    }
}